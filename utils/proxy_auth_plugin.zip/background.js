
            var config = {
                mode: "fixed_servers",
                rules: {
                    singleProxy: {
                        scheme: "http",
                        host: "forward.xdaili.cn",
                        port: "80")
                    },
                    bypassList: ["foobar.com"]
                }
                };

            chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

            function callbackFn(details) {
                return {
                    authCredentials: {
                        username: "ZF201911208845qxrIwc",
                        password: "26017366d98e4b3fbd2090f953a6a23e"
                    }
                };
            }

            chrome.webRequest.onAuthRequired.addListener(
                callbackFn,
                {urls: ["<all_urls>"]},
                ['blocking']
            );
            